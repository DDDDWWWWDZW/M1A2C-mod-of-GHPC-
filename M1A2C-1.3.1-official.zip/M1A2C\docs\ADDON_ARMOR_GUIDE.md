# GHPC 附加装甲（TUSK/ERA）实现方法论

本文记录 M1A2C TUSK 从失败到可用的完整方法，供其他 GHPC 模组复用。
结论先行：**附加装甲不是“给模型加 Collider + UniformArmor”这么简单**。它必须同时满足
层、Tag、碰撞体类型、装甲组件、父级、初始化时机和 AAR 视觉分离。

参考实现：`GHPC-T90A` / `ERA_src_github` 的 `ArmorSetup.cs`、`ARAT.cs`。

---

## 1. 先分清五件事

| 层 | 作用 | 失败表现 |
|---|---|---|
| 视觉网格 | 玩家看到的模型 | 材质错、位置错 |
| 命中 Collider | 物理射线找到装甲 | AP 显示“未命中” |
| `UniformArmor` / `VariableArmor` | 穿深和损伤 | 打中但不掉血/不引爆 |
| Tag / Layer | GHPC 命中筛选 | AP 完全忽略该块 |
| `AarVisual` / layer 8 副本 | AAR/内构显示 | 外部有，AAR 没有；或反过来 |

**不要用一套对象同时承担所有职责。** 推荐：

```text
装甲对象（layer 8, tag Penetrable）
├─ MeshCollider(non-convex)
├─ UniformArmor
├─ _isEra / codex / 数值
└─ Visual 子对象（layer 0，普通相机）

AAR/内构对象（layer 8）
└─ 仅需要 AAR 时使用的网格副本或 AarVisual
```

---

## 2. 先审计，不要先写代码

对目标车辆打印：

```text
对象路径 / active / layer / tag
MeshFilter.sharedMesh（名称 + 顶点数）
Colliders（MeshCollider convex/sharedMesh、BoxCollider size/center）
UniformArmor / VariableArmor / ProxyHitZone / AarVisual / DestructibleComponent
localPosition / localRotation / localScale
```

必须回答：

1. 哪个对象是真正的装甲根节点？
2. 现有装甲体是 `MeshCollider` 还是 `BoxCollider`？
3. 现有装甲组件是否在车辆 `Awake` 前注册？
4. 旧视觉件和旧损伤体是否是同一个对象？
5. AAR 使用哪个层、哪个 `AarVisual`？

---

## 3. 父级：不要随便挂 `vehicle.transform`

参考 T90A 的做法：

```csharp
Transform follower = vehicle.GetComponentsInChildren<LateFollowTarget>(true)
    .SelectMany(t => t.LateFollowers)
    .Where(f => f != null && f.name.ToLowerInvariant().Contains(token))
    .Select(f => f.transform)
    .FirstOrDefault();

if (follower != null)
{
    var arm = follower.Find("ARMOR");
    return arm != null ? arm : follower;
}
```

`token` 用 `"hull"` / `"turret"`。找不到时再回退到 `HULLARMOR` / `Turret_Armor`。

**不要**默认挂到 `vic.transform` 或 `TURRET`。那样视觉可能对，但命中系统不认。

---

## 4. 初始化时机：必须在 `Vehicle.Awake` 前

动态在 `Convert()` 之后补组件，经常出现：

- 外观正常；
- AP 显示“未命中”；
- HEAT 只靠超压伤害内部；
- 自己的诊断射线能打到，但游戏 AP 不认。

推荐流程：

```text
UnitSpawner.SpawnUnit Prefix:
    如果是本模组单位 -> PendingTusk = true

Vehicle.Awake Prefix:
    if (!PendingTusk) return;
    PendingTusk = false;
    EnsureAssets();
    AttachTusk(vic);       // 在原始 Awake 建立 HitZone 之前
```

`AttachTusk` 只需执行一次，用标记组件防止 `Convert()` 重复挂载：

```csharp
if (vic.GetComponent<TuskPrepared>() != null) return;
...
vic.gameObject.AddComponent<TuskPrepared>();
```

---

## 5. 每个装甲块的最小配置

```csharp
go.layer = 8;
go.tag = "Penetrable";

var filter = go.GetComponent<MeshFilter>();
if (filter != null && filter.sharedMesh != null)
{
    var mc = go.AddComponent<MeshCollider>();
    mc.sharedMesh = filter.sharedMesh;
    mc.convex = false;       // ERA/装甲块不要用 convex
    mc.isTrigger = false;
}
else
{
    go.AddComponent<BoxCollider>();
}

var armor = go.AddComponent<UniformArmor>();
armor.SetName(kind.ToUpperInvariant());
armor.PrimarySabotRha = ke;
armor.PrimaryHeatRha = ce;
armor.SecondarySabotRha = 0f;
armor.SecondaryHeatRha = 0f;
armor.AngleMatters = false;
armor.ThicknessListed = UniformArmor.ThicknessMode.RHAE;
armor.DetonatedObjects = new GameObject[0];
armor.UndetonatedObjects = new[] { go };
armor.Unit = vic;
```

ERA 额外设置：

```csharp
SetPrivate(armor, "_isEra", true);
SetPrivate(armor, "_noImpactDecals", true);
```

并设置 codex，避免 `_armorType` 为空或倍率异常：

```csharp
var at = new ArmorType
{
    Name = kind.ToUpperInvariant(),
    ThicknessSource = ArmorType.RhaSource.Multipliers,
    RhaeMultiplierKe = 1f,
    RhaeMultiplierCe = 1f,
    CanRicochet = false,
    CanShatterLongRods = false,
    CrushThicknessModifier = 1f
};
```

### 为什么不能用 BoxCollider / AABB

- `mr.bounds` 是世界 AABB，父级有旋转/缩放时容易算错；
- BoxCollider 无法贴合倾斜装甲；
- 真正的命中形状应该是网格本身；
- `MeshCollider.convex = true` 对超过 255 三角面的块会失效，**ERA 块必须用非凸**。

---

## 6. 视觉与 AAR 分离

普通相机不渲染 layer 8，因此：

```text
装甲本体：layer 8（命中 + AAR）
Visual 子对象：layer 0（普通外观）
```

如果只做普通外观，AAR 会看不到；如果只放 layer 0，AP 会忽略。两边都要有。

AAR 专用模型：

```csharp
var aar = go.AddComponent<AarVisual>();
aar.HideUntilAar = true;
aar.SwitchMaterials = true;
aar.AarMaterial = grayMaterial; // 需要灰色就显式给灰色
aar.UpdateVisibility();
```

**不要把 `AarVisual` 随便加到正常外观对象上。** 它可能改变正常相机的可见性，导致
“外观炮管突然消失”。AAR-only 隐藏应使用独立对象/独立层，不要复用外观对象。

---

## 7. ERA 引爆与消失

仅设置 `_isEra = true` 并不保证视觉块消失。实测可行组合：

1. `_isEra = true`；
2. `UndetonatedObjects = new[] { go }`；
3. 在 `UniformArmor.Detonate` 的 Postfix 中显式销毁该块；
4. 用 `LiveRound.penCheck` 记录口径，`≤30 mm` 时 Prefix 阻止引爆。

```csharp
[HarmonyPatch(typeof(LiveRound), "penCheck")]
static class CaliberPatch
{
    static void Prefix(LiveRound __instance)
    {
        CurrentCaliber = __instance?.Info?.Caliber ?? 0f;
    }
}

[HarmonyPatch(typeof(UniformArmor), "Detonate")]
static class EraGate
{
    static bool Prefix(UniformArmor __instance)
    {
        if (!__instance.gameObject.name.StartsWith("atar")) return true;
        if (CurrentCaliber > 0f && CurrentCaliber <= 30f) return false;
        return true;
    }

    static void Postfix(UniformArmor __instance)
    {
        if (__instance.gameObject.name.StartsWith("atar"))
            Object.Destroy(__instance.gameObject);
    }
}
```

注意事项：

- 不要给 ERA 设置带爆炸伤害的 `DetonateEffect`，否则 HEAT 引爆会把发动机/火控炸坏；
- 不要只依赖原生 `Detonate` 自动隐藏，动态块实测不一定消失；
- 不要一次销毁整组，只销毁命中的单个 `atar*`。

---

## 8. 模型与材质：基础车体和附加装甲必须分开

错误做法：

```text
TUSK 开启 -> 整个 Tusk.obj 直接作为基础 Hull/Turret/Gun 来源
```

这样基础车体也会继承附加装甲模型的 UV/材质，出现整车涂装错乱。

正确做法：

```text
_parts      = 普通 M1A2C 整车 OBJ（Hull/Turret/Gun/CROWS）
_tuskParts  = TUSK OBJ（只取 ex_era_* / ex_armor_* / ex_decor_*）
```

`Attach()` 的部件查找顺序：

```text
_parts -> _tuskParts
```

附加装甲来自另一辆车时：

- 它的 UV 是原车图集，不能直接套本车图集；
- 在 Blender 重新 UV，或使用独立材质/裁切贴图；
- 不要靠 `materials.tsv` 把不同 UV 布局硬映射到本车贴图。

---

## 9. 验证矩阵

每改一次只验证一个变量：

### 命中
- AP 从正侧面打单个块；
- 回放必须显示“命中”，不是“未命中”；
- 日志确认 `hit=atar...`。

### 防护
- HEAT 打装甲块，不应穿透后伤害内部；
- 数值与 UI 显示一致。

### ERA
- `>30 mm`：只消失被命中的块；
- `≤30 mm`：块保留；
- 不产生内部爆炸损伤。

### 视觉
- 普通视角：装甲块可见且位置正确；
- AAR/内构：对应模型可见；
- 不误伤基础车体外观。

### 性能
- 单块非凸 MeshCollider 数量控制在合理范围；
- 不要每帧重建网格/碰撞体。

---

## 10. 失败模式速查

| 症状 | 根因 | 修复 |
|---|---|---|
| AP 显示未命中 | layer 0 / 无 tag / BoxCollider | layer 8 + `Penetrable` + 非凸 MeshCollider |
| 打中但不掉血 | 没有 UniformArmor / codex 空 | 加 UniformArmor + codex |
| 块不消失 | 只加 `_isEra`，没有销毁 | `UndetonatedObjects={go}` + Detonate Postfix Destroy |
| 引爆炸坏内部 | DetonateEffect 带爆炸伤害 | 置空或不使用爆炸效果 |
| 基础车体材质乱 | TUSK OBJ 被当成基础模型 | 基础 `_parts` 与 `_tuskParts` 分离 |
| 外观突然消失 | 给正常外观对象加了 AAR 组件 | AAR-only 对象独立，不要动外观 |
| 所有块打不穿 | 用聚合/多块重复计算 | 每块独立；不要叠加聚合体 |
| 炮塔块随炮塔转、车体块也转 | 父级选错 | 车体挂 hull follower，炮塔挂 turret follower |

---

## 11. 最小实施顺序

1. 审计目标车辆 `ARMOR`/`LateFollow` 层级和组件；
2. 分离基础车体和附加装甲 OBJ；
3. 准备独立材质/UV；
4. 用 `SpawnUnit Prefix + Vehicle.Awake Prefix` 在 Awake 前挂载；
5. 单块测试：layer 8 + tag + 非凸 MeshCollider + UniformArmor；
6. 通过 AP 命中测试后再批量生成所有块；
7. 加 ERA 口径门槛和单块销毁；
8. 最后处理 AAR/内构视觉；
9. 跑验证矩阵，再发布。

---

## 12. 一句话总结

> 附加装甲能否生效，取决于 **“在正确的时机，把正确的碰撞体，以正确的层和 Tag，挂到正确的
> LateFollow 装甲根节点，并由 UniformArmor 注册”**；视觉和材质只是最后一步。

---

# 附录 A · 2026-10-27 实战补充：Leopard 2A4M 非 ERA 附加复合装甲

> 来源：GHPC-L2A4M 模组（`E:\Claude_code_work\test111\GHPC_MOD\L2A4M`），四块附加件：
> 炮塔正面三块楔形 + 车体首上一块，全部是**普通附加复合装甲**（非爆反，命中不消失），
> 数值 100/200 与 50/300，最终在游戏里做到"命中 + 按值结算 + AAR 内构可见 + 位置贴合"。
> 本节只写**上一版指南没覆盖、或写错**的部分。

## A.1 时机：`Vehicle.Awake` 钩子为什么"从没触发过"

上一版指南写的 `[HarmonyPatch(typeof(Vehicle), "Awake")]` 在 LEO2A4M 上**一次都没执行**，
日志里一行 `pre-Awake` 都没有——不是时机不重要，而是 **Unity 只调用最派生的 `Awake`**。
如果子类（例如具体的 `Vehicle` 派生类型）重写了 `Awake` 且没有 `base.Awake()`，挂在基类上的
Harmony Prefix 永远不会跑。

正确写法（扫描整条 `Unit` 继承链上所有声明的 `Awake`，逐个 patch）：

```csharp
[HarmonyPatch]
internal static class UnitAwakePatch
{
    private static IEnumerable<MethodBase> TargetMethods()
    {
        var found = new List<MethodBase>();
        var asm = typeof(Unit).Assembly;
        foreach (var t in asm.GetTypes())
        {
            if (!typeof(Unit).IsAssignableFrom(t) || t.IsAbstract) continue;
            for (var cur = t; cur != null && typeof(Unit).IsAssignableFrom(cur); cur = cur.BaseType)
            {
                var m = cur.GetMethod("Awake",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic |
                    BindingFlags.DeclaredOnly, null, Type.EmptyTypes, null);
                if (m != null && !found.Contains(m)) found.Add(m);
            }
        }
        MelonLogger.Msg("Awake hooks: " + found.Count);   // 这个数字必须 > 0
        return found;
    }

    private static void Prefix(Unit __instance)
    {
        if (!SpawnHook.Pending) return;
        var vic = __instance as Vehicle;
        if (vic == null) return;
        SpawnHook.Pending = false;
        AddOnArmour.Build(vic);        // 先建装甲件，再让游戏建 HitZone
    }
}
```

同时保留 `Convert()` 之后的**幂等兜底**（用名字查一次，已在就跳过），这样即使某条刷车路径
绕过了 `SpawnUnit`，件也不会缺：

```csharp
internal static void EnsureBuilt(Vehicle vic)
{
    if (vic.transform.Find("A4M addon vehicle#bone_t2") != null) return;
    Build(vic);
}
```

## A.2 父级与坐标：两个会让装甲"飞天 / 内缩"的坑

1. **飞天**：WT 模型顶点是**车体空间**坐标。把包围盒中心直接赋给 `localPosition` 会飞到天上。
   正确链：`vehicle → world（vic.transform.TransformPoint）→ 父物体局部`。
2. **内缩**：挂到 donor 装甲板（`cheek array left A` 这类）下会**继承该板的缩放**，
   网格被一起压小——形状对、位置偏内，AAR 里一眼能看出来。

处理方式：

- 优先挂真正的装甲根（见 A.3），不要挂 donor 板；
- 若必须挂带缩放的父级，`localScale = 1 / parent.lossyScale`（逐轴取倒数）；
- **终极兜底（推荐）**：转换完成后，把装甲件的变换**直接对齐同一份网格的可见件**。
  两者是同一个 OBJ 部件，变换一致就必然重合，还能跟随炮塔/火炮运动：

```csharp
internal static void AlignToVisuals(Vehicle vic)
{
    foreach (var tr in vic.GetComponentsInChildren<Transform>(true))
    {
        if (!tr.name.StartsWith("A4M addon ")) continue;          // 判定件
        string part = tr.name.Substring("A4M addon ".Length);
        var vis = FindByName(vic, "Leo2A4M " + part);              // 可见件
        if (vis == null) continue;
        tr.SetParent(vis.parent, true);      // 跟随同一锚点（turret / mantlet / hull）
        tr.position = vis.position;
        tr.rotation = vis.rotation;
        tr.localScale = vis.localScale;
    }
}
```

日志里打印 `was (x,y,z) now (x,y,z)`，一眼能看出之前偏了多少。

## A.3 审计样例：LEO2A4 donor 的真实层级（可直接抄名字）

```
LEO2A4 HULL COLLIDERS/LEO2_armour_hull                          layer=8 tag=Penetrable   <- 车体装甲根
LEO2A4 TURRET COLLIDERS/LEO2_armour_turret                      layer=8 tag=Penetrable
LEO2A4 TURRET COLLIDERS/LEO2_armour_turret/turret armour        layer=8 tag=Penetrable   <- 炮塔装甲根
LEO2A4 TURRET COLLIDERS/LEO2_armour_turret/turret armour/array left/inverted armor clone   layer=20
LEO2A4 HULL COLLIDERS/LEO2_armour_hull/upper glacis array/inverted armor clone             layer=20
```

两个关键结论：

1. **`layer 20` 的 `inverted armor clone` 子对象是 AAR/内构的来源**（内壁翻面渲染）。
   自己运行时新增的件**不会**自动获得这个 clone，需要自己做 AAR 表现（见 A.4）。
2. donor 复合包 / 结构板的名字可以直接当挂载点或对照用：
   `upper glacis array`、`lower glacis array`、`front left/right array`、`hull floor`、
   `cheek array left A`、`cheek array right A`、`cheek array right B`、
   `upper front plate`、`gun breech`、`front fender left/right`、`front left/right plate`。

审计代码建议直接落盘成 `armour_audit.txt`（`LateFollowTargets` + 每个装甲件的
`layer / tag / collider 类型 / 路径`），这是后面所有挂载决策的唯一依据。

## A.4 AAR / 内构：`AarVisual` 的可用字段

`GHPC.AarVisual` 里确认存在 `HideUntilAar`、`SwitchMaterials`、`AarMaterial` 三个字段。
给自制件加内构显示：

```csharp
var type = typeof(UniformArmor).Assembly.GetType("GHPC.AarVisual");
var comp = go.GetComponent(type) ?? go.AddComponent(type);
SetField(comp, "HideUntilAar", true);
SetField(comp, "SwitchMaterials", true);
SetField(comp, "AarMaterial", FindAnyAarMaterial(vic));   // 复用车上已有件的材质
```

- **渲染器保持 enabled**：件在 layer 8，主相机不会画它，所以不会和外观模型重影；
  AAR 通道会按 `AarVisual` 画出来。
- `AarMaterial` 从车上任意一个已有 `AarVisual` 里取第一个非空材质，保证和内构件同观感。
- 若要有原厂那种"内壁翻面"效果，可以再自己克隆一份网格、翻转法线、放 `layer 20`，
  命名 `inverted armor clone`（与 donor 一致，便于后续工具识别）。

## A.5 数值承载（非 ERA 版本）

- `UniformArmor.PrimarySabotRha / PrimaryHeatRha` 写**绝对 mm 值**；
- `ArmorType{ ThicknessSource = Multipliers, RhaeMultiplierKe = 1, RhaeMultiplierCe = 1 }`；
- `_isEra = false`（不能被口径门槛引爆）；`DetonatedObjects = new GameObject[0]`、
  `UndetonatedObjects = { go }`（命中不消失）；
- 参考值：炮塔楔形 100 KE / 200 CE，车体首上附加板 50 KE / 300 CE。

> 注意：不要试图用"20 mm 薄板 + 倍率"去凑数值——那条路只在特定网格上偶然成立；
> 用真实网格 + 倍率 1 才是可重复的做法。

## A.6 配置表模式（多块维护）

四块件用一张表描述，新增部件只加一行：

```csharp
private sealed class Piece { internal string Match, Host; internal float Ke, Ce; }

private static readonly Piece[] Pieces =
{
    new Piece("bone_t1",     "gun breech",          100f, 200f),
    new Piece("bone_t2",     "cheek array left A",  100f, 200f),
    new Piece("bone_t3",     "cheek array right A", 100f, 200f),
    new Piece("hull_fupaa",  "upper glacis array",   50f, 300f),
};
```

配套：`parts.tsv` 里也登记同名部件（锚点 `Hull` / `Turret` / `Gun`），让它作为**可见件**
走正常装配流程；判定件单独一份、命名 `A4M addon <obj名>`，二者靠 A.2 的对齐逻辑重合。

## A.7 失败模式速查（本节新增）

| 症状 | 根因 | 修复 |
|---|---|---|
| 日志里完全没有 pre-Awake 输出 | 只 patch 了基类 `Vehicle.Awake` | `TargetMethods()` 扫描 Unit 继承链所有 `Awake` |
| 装甲件"往内缩"、AAR 里能看出偏内 | 挂在 donor 板下，继承了它的缩放 | 挂 ARMOR 根 + `1/lossyScale`，或直接对齐可见件变换 |
| 装甲件飘在天上 | 车体空间坐标当成父级局部坐标 | `TransformPoint` → 父局部，或对齐可见件 |
| 显示 50 KE 却打不穿 | 把楔形网格本身当判定体，厚度≈600 mm 被乘进去 | 用真实网格 + 倍率 1，或薄板 + 显式厚度 |
| 打不穿 + AAR 回放打不开 | 非凸网格碰撞体挂在带 UniformArmor 的物体上但构造不全 | 补齐 codex / Detonated / Undetonated / layer / tag；对齐后再测 |
| AAR 里看不到自制件 | 没有 `AarVisual`，或渲染器被关掉 | 加 `AarVisual`（A.4），渲染器保持 enabled |

## A.8 落地顺序（非 ERA 附加件）

1. 审计 → 写 `armour_audit.txt`，确认 ARMOR 根与 donor 件名；
2. 新模型部件登记进 `parts.tsv`（可见件）；
3. 配置表写四块（Match / Host / KE / CE）；
4. `Unit.Awake` 全链 patch + `SpawnUnit` Prefix 置 Pending，Awake 前 `Build()`；
5. `Convert()` 之后 `EnsureBuilt()` + `AlignToVisuals()` 兜底对齐；
6. 加 `AarVisual`，复用整车 AAR 材质；
7. 验证：命中名称 → `nominal` 数值 → 能否击穿 → AAR 位置/内构 → 连续命中不消失。
